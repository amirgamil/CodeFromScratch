//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

/*
let costOfBanana = 1
let numberOfBananasInBasket = 17
 */

func findCostOfBasket(costOfBanana: Int, numberOfBananasInBasket: Int) -> (cost: Int, description: String){
    let finalCost = costOfBanana * numberOfBananasInBasket
    let finalDescription = "You need to pay $\(finalCost)"
    return (finalCost, finalDescription)
}

findCostOfBasket(costOfBanana: 1, numberOfBananasInBasket: 18)

findCostOfBasket(costOfBanana: 2, numberOfBananasInBasket: 10)

print(findCostOfBasket(costOfBanana: 1, numberOfBananasInBasket: 15))

let finalCost = findCostOfBasket(costOfBanana: 1, numberOfBananasInBasket: 14).cost
let finalDescription = findCostOfBasket(costOfBanana: 1, numberOfBananasInBasket: 14).description


func findMaxAndMin(integers: [Int]) -> (min: Int, max: Int){
    var currentMin = integers[0]
    var currentMax = integers[0]
    for integer in integers{
        if currentMin > integer{
            currentMin = integer
        }else if currentMax < integer{
            currentMax = integer
        }
    }
    return(currentMin, currentMax)
}

let maxValue = findMaxAndMin(integers: [2,3,6,8,9,11]).max
let minValue = findMaxAndMin(integers: [2,3,6,8,9,11]).min


//Argumemt Labels
func findInitalCostOfCoffee(volume: Int,numberOfSpoonsOfSugar sugar: Int) -> Int{
    let initalPrice = (volume * sugar)/100
    return initalPrice
}

func findFinalCostOfCoffee(typeOfCoffee type: String, volume: Int, numberOfSpoonsOfSugar sugar: Int) -> Int{
    let initalCost = findInitalCostOfCoffee(volume: volume, numberOfSpoonsOfSugar: sugar)
    var finalCost = 0
    switch type{
        case "Espresso": finalCost = initalCost + 1
        case "Cappuccino": finalCost = initalCost + 2
        case "Americano": finalCost = initalCost
        default: print("Couldn't identify type of coffee")
    }
    return finalCost
}

findFinalCostOfCoffee(typeOfCoffee: "Espresso", volume: 200, numberOfSpoonsOfSugar: 5)

//Default Values
func findCostOfBottle(volume: Int = 500) -> Int{
    var price = 0
    if volume == 500{
        price = 1
    } else if volume == 1500{
        price = 2
    }
    return price
}

findCostOfBottle(volume: 1500)

//Function Scope
func someFunction(){
    let someConstant = 2
    print(someConstant)
}

let someOtherConstant = 5









