//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



//Declaration of Struct

struct Location{
    let lat: Double
    let long: Double
    func isWithinRange(currentLocation: Location, deliveryLocation: Location) -> Bool{
        let differenceLat = deliveryLocation.lat - currentLocation.lat
        let differenceLong = deliveryLocation.long - currentLocation.long
        var shouldVanDeliver: Bool
        if differenceLat > 0.2 || differenceLat < -0.2{
            shouldVanDeliver = false
            
        } else if differenceLong > 0.2 || differenceLong < -0.2{
            shouldVanDeliver = false
        } else{
            shouldVanDeliver = true
        }
        return shouldVanDeliver
    }
    //Initializer
    init(lat: Double, long: Double) {
        self.lat = lat
        self.long = long
    }
}


class Van{
    var status: String
    var numberOfOrders: Int = 0
    var deliveredOrders: Int = 0
    var position: Location
    var currentOrder: String = ""
    
    init(status: String, lat: Double, long: Double){
        self.status = status
        self.position = Location(lat: lat, long: long)
    }
    
    func canDeliver(to location: Location) -> Bool{
        let canDeliver = position.isWithinRange(currentLocation: self.position, deliveryLocation: location)
        if canDeliver == true{
            print("Yay! I'm in range")
            deliver(to: location)
        } else{
            print("Unfortunately, I am not in range. Please check with another van")
        }
        return canDeliver
    }
    
    func deliver(to location: Location){
        self.status = "In Delivery"
        deliveredOrders += 1
    }
    
}


class Person{
    var recievedOrder: Bool = false
    let home: Location
    let order: String
    
    func orderFood(van: Van, order: String){
        if van.canDeliver(to: self.home){
            van.currentOrder = self.order
            van.numberOfOrders += 1
            recievedOrder = true
        }
    }
 
    init(lat: Double, long: Double, order: String) {
        self.home = Location(lat: lat, long: long)
        self.order = order
    }
}

class SuperVan: Van{
    let isSuper: Bool = true
    
    override init(status: String, lat: Double, long: Double){
        super.init(status: status, lat: lat, long: long)
        self.numberOfOrders = 3
    }
    
    override func canDeliver(to location: Location) -> Bool {
        var shouldVanDeliver: Bool
        let pendingOrders = self.numberOfOrders - self.deliveredOrders
        if pendingOrders > 5{
            shouldVanDeliver = false
            print("I have too many orders on my hands. Find another super van.")
        } else{
            print("I will deliver your order")
            shouldVanDeliver = true
            self.deliver(to: location)
        }
        return shouldVanDeliver
    }

}

let someVan = Van(status: "Waiting at Branch", lat: 34.05, long: 34.21)
let somePerson = Person(lat: 34.06, long: 34.12, order: "Cheeseburger")
somePerson.orderFood(van: someVan, order: somePerson.order)

let superVan = SuperVan(status: "Waiting at Branch", lat: 34.05, long: 34.21)
let someOtherPerson = Person(lat: 30, long: 28.6, order: "Double Chesseburger")
superVan.canDeliver(to: someOtherPerson.home)





