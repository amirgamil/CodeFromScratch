//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

struct Car{
    var color: String
    let modelNumber: Int
    let type: String
}

class Veichle{
    let numberOfWheels: Int
    var color: String
    let type: String
    
    init(numberOfWheels: Int, color: String, type: String){
        self.color = color
        self.numberOfWheels = numberOfWheels
        self.type = type
    }
}

//Value Types
let someCar = Car(color: "Red", modelNumber: 235, type: "Toyota")
var someOtherCar = someCar

someOtherCar.color = "Blue"

print(someOtherCar)

//Reference Types
let someVeichle = Veichle(numberOfWheels: 2, color: "Green", type: "Bike")
var someOtherVeichle = someVeichle

someOtherVeichle.color = "Red"

print(someVeichle.color)



