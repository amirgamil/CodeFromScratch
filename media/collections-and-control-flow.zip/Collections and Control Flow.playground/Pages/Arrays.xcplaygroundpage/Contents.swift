//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//Declaring an Array
var capitals = ["Bejing" , "Ottawa" , "London" , "Washington DC"]
let integers = [2 , 2 , 4 , 5]
var appleProducts = [String]()

//Reading from an Array
var bejing = capitals[0]
let london = capitals[2]

//Changing the value of a specific array
capitals[2] = "Abu Dhabi"
capitals[3] = "Cairo"
print(capitals)

//Appending one element to an array
capitals.append("Tokyo")
print(capitals.count)

//Appending multiple elements to an array
capitals.append(contentsOf: ["Paris","Berlin"])
print(capitals.count)

//Inserting an element into an array
var raceCarPositions = ["Red" , "Blue" , "Green" , "Yellow"]
raceCarPositions.insert("Purple", at: 1)
print(raceCarPositions)

//Removing an element from an array
raceCarPositions.remove(at: 3)
print(raceCarPositions)
