//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

var isViewGood = false


//If Else Statement
if isViewGood == true {
    print("The view is good. Go ahead and take a picture")
} else {
    print("The view isn't good. Walk away.")
}

//Else If Statements
var temperatureInCentigrade = 4

if temperatureInCentigrade >= 30{
    print("It's quite hot! Put on some sun cream and a hat")
} else if temperatureInCentigrade >= 20{
    print("The weather is great! Go outside and play!")
} else if temperatureInCentigrade >= 10{
    print("It's quite chilly! Put on a jacket")
} else {
    print("It's freezing! Stay inside or face the consequences")
}

//Logical Operators 

//Or Operators
var isWindy = false

if temperatureInCentigrade <= 20 || isWindy == true{
    print("It's quite cold! You should consider a jacket in this weather")
}

//And Operators
var isRainy = false

if temperatureInCentigrade <= 20 && isRainy == true{
    print("It's raining and cold. You definitely want stay inside in this weather")
}











