//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

/*
 A    :    Apple
 B    :    Banana
 C    :    Cow
 D    :    Dog
 E    :    Egg
 
 */

var lettersOfTheAlphabet: [String:String] = ["A" : "Apple",
                                             "B" : "Banna",
                                             "C" : "Cow",
                                             "D" : "Dog",
                                             "E" : "Egg"]
print(lettersOfTheAlphabet)

var someDictionary: [Int:String] = [4: "Four",
                                    5: "Five"]



//Reading from a dictionary
//Make sure the keys are all typed in precisely in the exact same way they were defined
let apple = lettersOfTheAlphabet["A"]
let dog = lettersOfTheAlphabet["D"]
let four = someDictionary[4]

//Modifying values from a dictionary
lettersOfTheAlphabet["E"] = "Excellent"
lettersOfTheAlphabet["C"] = "Car"

//Insert new key value pairs into a dictionary
lettersOfTheAlphabet["F"] = "Fantastic"
print(lettersOfTheAlphabet)

//Removing key values
lettersOfTheAlphabet.removeValue(forKey: "B")
print(lettersOfTheAlphabet)




