//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)


//While Loop
var x = 0

while x < 10 {
    x += 1
    print(x)
}

//Repeat While Loop
var y = 0

repeat {
    print(y)
} while y != 0

