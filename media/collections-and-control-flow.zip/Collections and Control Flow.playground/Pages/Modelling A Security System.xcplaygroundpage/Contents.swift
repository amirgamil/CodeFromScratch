//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

/*
 
 Variables
    Input of username and password
    Current number of attempts
 
 Constants
    Maximum number of attempts
    Correct username and password
 
 
 Loop we are going to use: While
 */

var username = "correctUsername"
var password = "correctPassword"
var currentNumberOfAttempts = 0
let maximumNumberOfAttempts = 3
let correctUsername = "correctUsername"
let correctPassword = "correctPassword"

while currentNumberOfAttempts != maximumNumberOfAttempts{
    currentNumberOfAttempts += 1
    
    if username == correctUsername && password == correctPassword{
        print("Successfully logged in after \(currentNumberOfAttempts) attempts")
        break
    } else{
        print("Username or Password is incorrect")
    }
    
    if currentNumberOfAttempts == maximumNumberOfAttempts{
        print("Unfortunately, your account has been locked out because you have had the maxiumum number of attempts.")
    }
    
}





