//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

//Iterating over an array
let names = ["John","Josh","Ryan","Amir"]

for name in names{
    print("Hi \(name), nice to meet you")
}

//Iterating over a dictionary
let countriesAndCapitals = ["England":"London","USA":"Washington DC", "Japan":"Tokyo"]

for (country, capital) in countriesAndCapitals{
    print(country)
}


//Iterating over a specific sequence
for i in 1...5{
    print(i)
}

//Iterating over a specific sequence without using the pointer
for _ in 1...10{
    print("Hi")
}

for sixTimesTable in 1...10{
    print("\(sixTimesTable) multiplied by 6 is \(sixTimesTable*6)")
}



