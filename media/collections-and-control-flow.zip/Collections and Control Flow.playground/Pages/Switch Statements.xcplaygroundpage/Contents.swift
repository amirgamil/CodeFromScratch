//: [Previous](@previous)

import Foundation

var str = "Hello, playground"

//: [Next](@next)

let capitals = ["London" , "Washington DC" , "Cairo" , "Paris" , "Madrid"]

for capital in capitals{
    switch capital{
        case "London": print("England")
        case "Washington DC": print("U.S.A")
        case "Cairo": print("Egypt")
        case "Paris": print("France")
        case "Madrid": print("Spain")
        default: print("Could not find cooresponding country.")
    }
}

let devices = ["iPhone" , "Mac" , "Microsoft Book" , "Surface Pro" , "Chromecast" , "Apple TV"]

for device in devices{
    switch device{
        case "iPhone","Mac","Apple TV": print("Apple")
        case "Microsoft Book","Surface Pro": print("Microsoft")
        case "Chromecast": print("Google")
        default: print("Could not find cooresponding company.")
    }
}
