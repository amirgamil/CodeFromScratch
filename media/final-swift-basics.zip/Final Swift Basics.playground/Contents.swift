//: Playground - noun: a place where people can play

import UIKit


//Variables
var str = "Hello, playground"


//Constants
let name = "Amir"


//Username
//Password

var username = ""
var password = ""
let maximumNumberOfAttempts = 3

//Conventional Rules

// 1 - Names must always be useful

//Good name
var programmingLanguage = "Swift"

//Bad name
var x = "Swift"

// 2 - Can't have white space between names of variables and constants

var anotherProgrammingLanguage = "Javascript"


programmingLanguage

