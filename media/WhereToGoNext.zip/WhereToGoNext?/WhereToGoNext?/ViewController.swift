//
//  ViewController.swift
//  WhereToGoNext?
//
//  Created by Amir on 2/22/17.
//  Copyright © 2017 CodeFromScratch. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var factLabel: UILabel!
    @IBOutlet weak var cityImage: UIImageView!
    @IBOutlet weak var actionButton: UIButton!
    
    let location = LocationModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        showALocation()
    }
    
    func showALocation(){
        let randomLocation = location.returnALocation()
        cityLabel.text = randomLocation.cityName
        factLabel.text = randomLocation.cityFact
        cityImage.image = randomLocation.cityImage
    }
    
    @IBAction func showAnotherLocation() {
        showALocation()
    }
    
}





