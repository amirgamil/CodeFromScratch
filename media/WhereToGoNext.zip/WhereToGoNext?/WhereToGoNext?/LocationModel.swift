//
//  LocationModel.swift
//  WhereToGoNext?
//
//  Created by Amir on 2/28/17.
//  Copyright © 2017 CodeFromScratch. All rights reserved.
//

import UIKit
import GameKit

struct LocationModel{
    let cityLocations = ["Paris", "London", "Cairo", "Tokyo", "New York", "Rome"]
    let cityImages = [#imageLiteral(resourceName: "paris"), #imageLiteral(resourceName: "london"), #imageLiteral(resourceName: "cairo"), #imageLiteral(resourceName: "tokyo"), #imageLiteral(resourceName: "new-york"), #imageLiteral(resourceName: "rome")]
    let cityFacts = ["Paris was originally a Roman City called Lutetia.","Big Ben is the bell, not the clock tower. Its chime is in the key of E.","The first Egyptian pyramid is believed to be the Pyramid of Djoser, it was built in Saqqara around 4650 years ago (2640 BC).","The Eiffel Tower was the inspiration for the Tokyo Tower. The tower is repainted every five years, a process that takes 12 months each time. ","New York City has 722 miles of subway track.","Ancient Rome was eight times more densely populated than modern New York."]
    
    func returnALocation() -> (cityName: String, cityImage: UIImage, cityFact: String){
        let randomNumber = GKRandomSource.sharedRandom().nextInt(upperBound: 6)
        let city = cityLocations[randomNumber]
        let cityImage = cityImages[randomNumber]
        let cityFact = cityFacts[randomNumber]
        
        return (city, cityImage, cityFact)
    }
    
}


