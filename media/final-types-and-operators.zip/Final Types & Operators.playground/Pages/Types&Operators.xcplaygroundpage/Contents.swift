//Types Introduction
var name: String = "Amir"
var age: Int = 15

var amountSaved: Float

amountSaved = 150.2

var username: String
var password: String

//Strings

let someString = "someText\nanotherText"
print(someString)

//Concatenation
let string1 = "String 1"
let string2 = " String 2"
let concactenatedString = string1 + string2

var country = "United States"
country += " of America"

//String Interpolation
let programmingLanguage = "Swift"
var introductionToProgrammingLanguage = "\(programmingLanguage) is an amazing programming language"

let multiplier = 8
let finalOutput = "4 multiplied by \(multiplier) is equal to 32"
print(finalOutput)

//Integer
let numberOfMonths = 12

//Floating Point Numbers
let pi = 3.14159265

let someInteger = 7

//Boolean Values
let isGoingToTheMall = true
print(isGoingToTheMall)
var isAwesome = false
isAwesome = true

//-------Operators----------//

//Assignment Operator
let b = 0
var a = b


//Arithemtic Operators

//Addition
var exampleOfAddition = 5 + 8
1 + 8

//Subtraction
9 - 8

//Multiplication
4 * 8

//Division
4 / 7

//Remainder Operators
let remainderExample = 5 % 2
10 % 4


//Unary Operators
let three = 3
let minusThree = -three

let alsoMinusThree = +minusThree

//Compound Assignment Operators
var d = 7
d += 2

//Comparison Operators
let numberSeven = 7
let alsoNumberSeven = 7
let six = 6
//Equal to
numberSeven == alsoNumberSeven

//Not Equal to
numberSeven != alsoNumberSeven

//Greater
numberSeven > alsoNumberSeven

//Less than
six < numberSeven

//Greater than or equal to
numberSeven >= alsoNumberSeven

//Less than or equal to
alsoNumberSeven <= six



